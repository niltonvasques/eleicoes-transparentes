#!/bin/bash


find . -type f >>paths

while read line
do  
	python Txt2JSON.py $linei
	rm $file
done < paths
