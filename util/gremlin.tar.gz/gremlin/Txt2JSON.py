#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import re
import sys


pathSource = sys.argv[1]
fileSource = open(pathSource,'r')


pathTarget = pathSource.replace('.txt','.json')
fileTarget = open(pathTarget,'w')

header = fileSource.readline()

header = header.split(';')

size = len(header) - 1

body = fileSource.readlines()
countLines = len(body)


def formatHeader(h):
        h = h.replace(" ","_")
        h = h.replace("\"","")
        h = re.sub("[^A-Za-z0-9]+", '_', h)
        h = "\""+ h + "\""
        return h.lower()

def getFileName(path):
        fileName =  os.path.splitext(path)[0]
        fileName = fileName.split('/')
        fileName = fileName[len(fileName)-1]
        return fileName


def transformation():
        fileTarget.write("{\n\"")
	fileTarget.write(getFileName(pathSource))
	fileTarget.write("\": \n[\n")

        i = 0
	j = 0
        for line in body:
                fileTarget.write("\t{\n")
                line = line.split(';')
                for cell in line:
                        fileTarget.write("\t"+formatHeader(header[i])+":"+cell)
                        if i < size:
                                 fileTarget.write(",\n")
                        i = i+1
                i = 0
		j = j +1
		if j < countLines -1:
	                fileTarget.write("\t},\n")
		else:
	                fileTarget.write("\t}\n")
			
		

        fileTarget.write("]\n}")
        return

if body:
        transformation()

fileSource.close()
fileTarget.close()

